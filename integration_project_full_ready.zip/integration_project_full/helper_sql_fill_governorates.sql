-- Example to add governorates and agents
INSERT INTO agents (name, phone, governorate, webhook_url) VALUES ('محمود','tg:123456789','القاهرة','https://example.com/agent/webhook');
INSERT INTO governorates (name, sheet_id, default_agent_id) VALUES ('القاهرة', '<sheet_id_here>', 1);