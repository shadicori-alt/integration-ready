require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const db = require('./db/database');

const aiRoutes = require('./routes/aiRoutes');
const orderRoutes = require('./routes/orderRoutes');
const connectorsRoutes = require('./routes/connectorsRoutes');
const fbWebhook = require('./routes/fbWebhook');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(cors());
app.use(bodyParser.json({ limit: '1mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

const limiter = rateLimit({ windowMs: 15*60*1000, max: 400 });
app.use(limiter);

app.use(express.static(path.join(__dirname, '../public')));

app.use('/api/ai', aiRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/connectors', connectorsRoutes);
app.use('/webhook/facebook', fbWebhook);

// admin login (simple)
app.post('/api/admin/login', (req,res) => {
  const { username, password } = req.body;
  if (username === process.env.ADMIN_USER && password === process.env.ADMIN_PASS) {
    const jwt = require('jsonwebtoken');
    const token = jwt.sign({ user: username }, process.env.JWT_SECRET||'devsecret', { expiresIn: '8h' });
    return res.json({ token });
  }
  res.status(401).json({ error: 'Unauthorized' });
});

// socket events
io.on('connection', (socket) => {
  console.log('Socket connected', socket.id);
});

// notify endpoint
app.post('/api/notify/new-order', (req,res) => {
  io.emit('new-order', req.body);
  res.json({ ok: true });
});

server.listen(PORT, ()=>console.log(`🚀 Server running at http://localhost:${PORT}`));