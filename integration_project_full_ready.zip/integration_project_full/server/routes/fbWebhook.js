const express = require('express');
const router = express.Router();
const aiBridge = require('../controllers/AI_Integration_Bridge')();
const db = require('../db/database');

// verify webhook
router.get('/webhook', (req,res) => {
  const VERIFY_TOKEN = process.env.FB_VERIFY_TOKEN || 'fb_verify_token';
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode && token) {
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      console.log('FB webhook verified');
      return res.status(200).send(challenge);
    } else return res.sendStatus(403);
  } else return res.sendStatus(400);
});

router.post('/webhook', async (req,res) => {
  try {
    const body = req.body;
    if (body.object === 'page') {
      for (const entry of body.entry) {
        if (entry.messaging) {
          for (const msgEvent of entry.messaging) {
            if (msgEvent.message && msgEvent.sender) {
              const senderId = msgEvent.sender.id;
              const text = msgEvent.message.text || '';
              const result = await aiBridge.handleMessage(senderId, text, { platform: 'messenger' });
              if (result && result.response) {
                try { await aiBridge.sendToFacebookPSID(senderId, result.response); } catch(e){ console.warn('sendToFacebookPSID failed', e.message); }
              }
            }
          }
        }
        if (entry.changes) {
          for (const change of entry.changes) {
            if (change.field === 'feed') {
              const comment = change.value;
              const commentId = comment.comment_id || comment.id;
              const message = comment.message || '';
              const from = comment.from ? comment.from.id : null;
              const aiResult = await aiBridge.handleMessage(from || 'anon', message, { platform: 'facebook_comment' });
              try { await aiBridge.replyToComment(commentId, aiResult.response); } catch(e){ console.warn('replyToComment failed', e.message); }
            }
          }
        }
      }
      return res.status(200).send('EVENT_RECEIVED');
    } else return res.sendStatus(404);
  } catch (err) {
    console.error('FB webhook processing error', err);
    return res.sendStatus(500);
  }
});

module.exports = router;