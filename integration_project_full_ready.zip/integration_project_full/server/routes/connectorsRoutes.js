const express = require('express');
const router = express.Router();
const db = require('../db/database');
const aiBridge = require('../controllers/AI_Integration_Bridge')();

// save apps script webhook
router.post('/settings/apps-script', (req,res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'url required' });
  db.run(`INSERT OR REPLACE INTO settings (key, value) VALUES ('apps_script_webhook', ?)`, [url], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    const instance = require('../controllers/AI_Integration_Bridge')();
    instance.config.appsScriptWebhook = url;
    res.json({ success: true });
  });
});

// save fb token
router.post('/settings/fb', (req,res) => {
  const { pageToken } = req.body;
  if (!pageToken) return res.status(400).json({ error: 'pageToken required' });
  db.run(`INSERT OR REPLACE INTO settings (key, value) VALUES ('fb_page_token', ?)`, [pageToken], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    const instance = require('../controllers/AI_Integration_Bridge')();
    instance.config.fbPageToken = pageToken;
    res.json({ success: true });
  });
});

// save telegram token
router.post('/settings/telegram', (req,res) => {
  const { token } = req.body;
  if (!token) return res.status(400).return res.status(400).json({ error: 'token required' });
  db.run(`INSERT OR REPLACE INTO settings (key, value) VALUES ('telegram_token', ?)`, [token], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    const instance = require('../controllers/AI_Integration_Bridge')();
    instance.config.telegramToken = token;
    instance.config.whatsappToken = process.env.WHATSAPP_CLOUD_TOKEN || instance.config.whatsappToken;
    res.json({ success: true });
  });
});

module.exports = router;