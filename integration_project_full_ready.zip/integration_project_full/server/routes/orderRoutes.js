const express = require('express');
const router = express.Router();
const db = require('../db/database');
const aiBridge = require('../controllers/AI_Integration_Bridge')();

router.post('/create', async (req,res) => {
  try {
    const { customer_name, customer_phone, governorate, details } = req.body;
    if (!customer_name || !customer_phone || !governorate) return res.status(400).json({ error: 'missing fields' });
    const orderData = { customer_name, customer_phone, governorate, details };
    const order = await aiBridge.createOrder(orderData);
    res.json({ success: true, order });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/all', (req,res) => {
  db.all('SELECT * FROM orders ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

module.exports = router;