const express = require('express');
const router = express.Router();
const aiBridge = require('../controllers/AI_Integration_Bridge')();

router.post('/chat', async (req,res) => {
  try {
    const { message, customerId, platform, use } = req.body;
    if (!message) return res.status(400).json({ error: 'message required' });
    const out = await aiBridge.handleMessage(customerId || 'anon', message, { platform, use });
    res.json(out);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;