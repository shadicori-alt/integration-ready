// Local AI controller: keyword-based Arabic classifier + sentiment
class LocalAIController {
  constructor() {
    this.responses = {
      greetings: ['مرحباً! أهلاً وسهلاً بك 👋', 'أهلاً! كيف أقدر أساعدك اليوم؟ 😊'],
      orders: ['هل تود أن أساعدك في إنشاء طلب الآن؟ 📦', 'أخبرني تفاصيل الطلب وسأقوم بتسجيله.'],
      complaints: ['نعتذر عن الإزعاج 😔 سنتابع ونعالج المشكلة سريعاً.', 'نأسف لذلك — سنقوم بالتحقيق فوراً.'],
      prices: ['سأزودك بأسعارنا الآن 💰', 'هل تبحث عن سعر منتج معين؟'],
      delivery: ['نقدّم خدمة توصيل سريعة 🚚', 'التوصيل متاح لجميع المحافظات.'],
      working_hours: ['ساعات العمل: 9ص - 9م يومياً 🕘', 'متاحون طوال أيام الأسبوع.'],
      payment: ['نقبل الدفع عند الاستلام أو تحويل بنكي 💳', 'طرق الدفع مرنة وآمنة.'],
      default: ['شكراً لتواصلك، سنرد عليك قريباً ⏰']
    };
    this.keywords = {
      greetings: ['مرحبا','أهلا','السلام','اهلا'],
      orders: ['طلب','شراء','عايز','محتاج','اطلب'],
      complaints: ['شكوى','مشكلة','خطأ','عيب','غلط'],
      prices: ['سعر','بكم','تكلفة'],
      delivery: ['توصيل','شحن','مندوب'],
      working_hours: ['متى','ساعات','متى تفتح'],
      payment: ['دفع','نقد','تحويل','كاش']
    };
    console.log('🤖 Local AI Controller initialized');
  }

  classifyMessage(msg='') {
    if (!msg) return 'default';
    const text = msg.toLowerCase();
    let best='default', bestScore=0;
    for (const [cat,kws] of Object.entries(this.keywords)) {
      let score=0;
      for (const kw of kws) if (text.includes(kw)) score += kw.length;
      if (score > bestScore) { bestScore = score; best = cat; }
    }
    return best;
  }

  analyzeSentiment(msg='') {
    const text = msg.toLowerCase();
    const positive = ['ممتاز','رائع','شكرا','شكراً','جيد','راضي','سعيد','مبسوط'];
    const negative = ['سيء','مشكلة','خطأ','غضب','غير راضي','مستاء','زعج'];
    let p=0,n=0;
    for (const w of positive) if (text.includes(w)) p++;
    for (const w of negative) if (text.includes(w)) n++;
    if (p>n) return { sentiment:'positive', score: p-n };
    if (n>p) return { sentiment:'negative', score: n-p };
    return { sentiment:'neutral', score:0 };
  }

  getRandomResponse(category='default') {
    const arr = this.responses[category] || this.responses.default;
    return arr[Math.floor(Math.random()*arr.length)];
  }

  // Returns object {response, category, sentiment}
  generateResponse(message, context={}) {
    const cat = this.classifyMessage(message || '');
    let resp = this.getRandomResponse(cat);
    if (context.orderNumber) resp += "\n\n📋 رقم الطلب: " + context.orderNumber;
    if (cat === 'complaints') resp += "\n⏰ سنرد خلال 2-4 ساعات كحد أقصى";
    else if (cat === 'orders' || cat === 'prices') resp += "\n⏰ سيتم التواصل خلال ساعة";
    const sentiment = this.analyzeSentiment(message || '');
    return { response: resp, category: cat, sentiment };
  }

  async generateResponseAdvanced(message, options={}) {
    return this.generateResponse(message, options.context || {});
  }
}

module.exports = LocalAIController;
