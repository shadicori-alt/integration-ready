const LocalAIController = require('./LocalAI_Controller');
const db = require('../db/database');
const axios = require('axios');

class AIBridge {
  constructor(config = {}) {
    this.localAI = new LocalAIController();
    this.config = {
      fbPageToken: process.env.FB_PAGE_TOKEN || null,
      telegramToken: process.env.TELEGRAM_BOT_TOKEN || null,
      whatsappToken: process.env.WHATSAPP_CLOUD_TOKEN || null,
      whatsappApiUrl: process.env.WHATSAPP_API_URL || null,
      deepstackUrl: process.env.DEEPSTACK_URL || null,
      deepstackKey: process.env.DEEPSTACK_API_KEY || null,
      appsScriptWebhook: process.env.APPS_SCRIPT_WEBHOOK || null,
      ...config
    };
    db.get("SELECT value FROM settings WHERE key='apps_script_webhook'", [], (err,row)=> {
      if (!err && row) this.config.appsScriptWebhook = row.value;
    });
    console.log('🤖 AI Bridge initialized');
  }

  async handleMessage(senderId, messageText, meta = {}) {
    const start = Date.now();
    let aiOut;
    if (meta.use === 'deepstack' && this.config.deepstackUrl) {
      aiOut = await this.localAI.generateResponseAdvanced(messageText, meta);
    } else {
      aiOut = await this.localAI.generateResponseAdvanced(messageText, meta);
    }

    const { response, category, sentiment } = aiOut;
    await this.logConversation({
      orderId: meta.orderId || null,
      customerId: senderId,
      message: messageText,
      response,
      category,
      sentiment,
      platform: meta.platform || 'unknown'
    });
    return { response, category, sentiment, responseTime: Date.now()-start, source: (meta.use||'local_ai') };
  }

  logConversation(data) {
    return new Promise((resolve, reject) => {
      const q = `INSERT INTO conversations (order_id, customer_id, message, response, category, sentiment, platform)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;
      db.run(q, [
        data.orderId || null,
        data.customerId || null,
        data.message || '',
        data.response || '',
        data.category || '',
        JSON.stringify(data.sentiment || {}),
        data.platform || 'unknown'
      ], function(err) {
        if (err) return reject(err);
        resolve(this.lastID);
      });
    });
  }

  createOrder(orderData) {
    return new Promise((resolve, reject) => {
      const q = `INSERT INTO orders (order_number, customer_name, customer_phone, governorate, details, assigned_agent_id)
                 VALUES (?, ?, ?, ?, ?, ?)`;
      const orderNumber = `ORD-${Date.now()}`;
      db.run(q, [
        orderNumber,
        orderData.customer_name,
        orderData.customer_phone,
        orderData.governorate,
        orderData.details || '',
        orderData.assigned_agent_id || null
      ], async function(err) {
        if (err) return reject(err);
        const newOrderId = this.lastID;
        const order = { id: newOrderId, order_number: orderNumber, ...orderData };
        try { await AIBridgeInstance.pushOrderToGovernorate(order); } catch(e){ console.warn('pushOrderToGovernorate failed', e.message); }
        resolve(order);
      });
    });
  }

  pushOrderToGovernorate(order) {
    return new Promise((resolve, reject) => {
      db.get('SELECT sheet_id, default_agent_id FROM governorates WHERE name = ?', [order.governorate], async (err, row) => {
        if (err) return reject(err);
        db.get("SELECT value FROM settings WHERE key='apps_script_webhook'", [], async (e, r) => {
          try {
            if (r && r.value) {
              await axios.post(r.value, { order, governorate: order.governorate });
            } else if (this.config.appsScriptWebhook) {
              await axios.post(this.config.appsScriptWebhook, { order, governorate: order.governorate });
            } else {
              console.warn('No Apps Script webhook configured; order saved locally.');
            }

            if (row && row.default_agent_id) {
              db.get('SELECT webhook_url, phone FROM agents WHERE id=?', [row.default_agent_id], async (err2, agent) => {
                if (!err2 && agent && agent.webhook_url) {
                  try { await axios.post(agent.webhook_url, { order }); } catch (err3) { console.error('Failed to send to agent', err3.message); }
                }
                if (agent && agent.phone) {
                  try { await this.notifyAgentViaChat(agent, order); } catch (e2) { console.warn('notifyAgentViaChat failed', e2.message); }
                }
              });
            }

            resolve(true);
          } catch (errx) { reject(errx); }
        });
      });
    });
  }

  async notifyAgentViaChat(agent, order) {
    const text = `طلب جديد: ${order.order_number}\n${order.customer_name} • ${order.customer_phone}\nمحافظة: ${order.governorate}\nتفاصيل: ${order.details || '-'}`;
    if (this.config.telegramToken && agent.phone && agent.phone.startsWith('tg:')) {
      const chatId = agent.phone.replace('tg:', '');
      const url = `https://api.telegram.org/bot${this.config.telegramToken}/sendMessage`;
      try { await axios.post(url, { chat_id: chatId, text }); } catch (err) { console.warn('Telegram notify error', err.message); }
    } else if (this.config.whatsappToken && agent.phone && /^\d+$/.test(agent.phone) && this.config.whatsappApiUrl) {
      try {
        await axios.post(this.config.whatsappApiUrl, {
          messaging_product: "whatsapp",
          to: agent.phone,
          type: "text",
          text: { body: text }
        }, { headers: { Authorization: `Bearer ${this.config.whatsappToken}` } });
      } catch (err) { console.warn('WhatsApp notify error', err.message); }
    }
  }

  async sendToFacebookPSID(psid, text) {
    if (!this.config.fbPageToken) throw new Error('FB_PAGE_TOKEN missing');
    const url = `https://graph.facebook.com/v16.0/me/messages?access_token=${this.config.fbPageToken}`;
    try { await axios.post(url, { recipient: { id: psid }, message: { text } }); return true; }
    catch (err) { console.error('FB send error', err.message); return false; }
  }

  async replyToComment(commentId, text) {
    if (!this.config.fbPageToken) throw new Error('FB_PAGE_TOKEN missing');
    const url = `https://graph.facebook.com/v16.0/${commentId}/comments?access_token=${this.config.fbPageToken}`;
    try { await axios.post(url, { message: text }); return true; }
    catch (err) { console.error('FB comment reply error', err.message); return false; }
  }

  async sendTelegram(chatId, text) {
    if (!this.config.telegramToken) throw new Error('TELEGRAM_BOT_TOKEN missing');
    const url = `https://api.telegram.org/bot${this.config.telegramToken}/sendMessage`;
    try { await axios.post(url, { chat_id: chatId, text }); return true; }
    catch (err) { console.error('Telegram send error', err.message); return false; }
  }

  updateConfig(newConf) {
    this.config = { ...this.config, ...newConf };
    db.run(`INSERT OR REPLACE INTO settings (key, value) VALUES ('ai_bridge_config', ?)`, [JSON.stringify(this.config)], (err) => {
      if (err) console.warn('Failed to save AI bridge config', err.message);
    });
  }
}

let AIBridgeInstance = null;
module.exports = (function getInstance(config) {
  if (!AIBridgeInstance) AIBridgeInstance = new AIBridge(config || {});
  return AIBridgeInstance;
})();