const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const DB_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DB_DIR, 'enhanced_workflow_system.db');
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) console.error('❌ SQLite Error:', err);
  else console.log('✅ SQLite DB connected at', DB_PATH);
});
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT,
    customer_name TEXT,
    customer_phone TEXT,
    governorate TEXT,
    details TEXT,
    assigned_agent_id INTEGER,
    status TEXT DEFAULT 'new',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    customer_id TEXT,
    message TEXT,
    response TEXT,
    category TEXT,
    sentiment TEXT,
    platform TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    governorate TEXT,
    webhook_url TEXT,
    active INTEGER DEFAULT 1
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS governorates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE,
    sheet_id TEXT,
    default_agent_id INTEGER
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  )`);
});
module.exports = db;
