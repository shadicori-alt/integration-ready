# Integration AI - Facebook / Telegram / WhatsApp / Google Sheets / DeepStack

هذا المشروع هو أداة تكامل شاملة تربط الذكاء الاصطناعي المحلي (Local AI) أو DeepStack أو OpenAI (اختياري)، مع فيسبوك ماسنجر، تعليقات فيسبوك، تلغرام، واتساب (Cloud API)، وGoogle Sheets عبر Google Apps Script Web App. كما يتضمن لوحة تحكم بسيطة بالعربية وتطبيق مندوب.

## كيف تبدأ
1. انسخ `.env.example` إلى `.env` واملأ القيم المطلوبة.
2. شغّل:
   ```
   npm install
   npm run dev
   ```
3. افتح:
   - http://localhost:3000/  => واجهة اختبار AI
   - http://localhost:3000/admin.html => لوحة التحكم
   - http://localhost:3000/agent.html => تطبيق المندوب البسيط
